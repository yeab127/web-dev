import { Home, Wrench, Camera, Car, Music, Bike } from "lucide-react";
import { Link } from "react-router-dom";

const categories = [
  {
    icon: Home,
    name: "Properties",
    description: "Homes, apartments & shared spaces",
    count: "2,500+",
    color: "bg-primary/10 text-primary",
  },
  {
    icon: Wrench,
    name: "Tools & Equipment",
    description: "Power tools, machinery & gear",
    count: "1,800+",
    color: "bg-secondary/10 text-secondary",
  },
  {
    icon: Camera,
    name: "Photography",
    description: "Cameras, lenses & lighting",
    count: "600+",
    color: "bg-accent/10 text-accent",
  },
  {
    icon: Car,
    name: "Vehicles",
    description: "Cars, vans & trailers",
    count: "400+",
    color: "bg-primary/10 text-primary",
  },
  {
    icon: Music,
    name: "Audio & Music",
    description: "Instruments & sound equipment",
    count: "350+",
    color: "bg-secondary/10 text-secondary",
  },
  {
    icon: Bike,
    name: "Sports & Outdoor",
    description: "Bikes, camping & adventure gear",
    count: "700+",
    color: "bg-accent/10 text-accent",
  },
];

const Categories = () => {
  return (
    <section className="py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Explore by <span className="text-primary">Category</span>
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            From entire homes to specialized equipment, discover what's available in your area.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category, index) => {
            const Icon = category.icon;
            return (
              <Link
                key={index}
                to="/browse"
                className="group bg-card p-8 rounded-2xl border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg"
              >
                <div className={`w-16 h-16 rounded-xl ${category.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors">
                  {category.name}
                </h3>
                <p className="text-foreground/70 mb-3">{category.description}</p>
                <p className="text-sm font-medium text-primary">{category.count} listings</p>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Categories;
