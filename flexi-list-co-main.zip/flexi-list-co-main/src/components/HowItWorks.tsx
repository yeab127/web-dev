import { Search, MessageCircle, Shield, Star } from "lucide-react";

const steps = [
  {
    icon: Search,
    title: "Browse & Discover",
    description: "Explore thousands of properties and equipment listings in your area. Filter by category, price, and availability.",
  },
  {
    icon: MessageCircle,
    title: "Connect & Communicate",
    description: "Message owners directly, ask questions, and arrange viewing or pickup times that work for both parties.",
  },
  {
    icon: Shield,
    title: "Secure Transaction",
    description: "Complete bookings with our secure payment system. Your money is protected until the rental is confirmed.",
  },
  {
    icon: Star,
    title: "Rate & Review",
    description: "Share your experience and help build trust in our community. Both renters and owners can leave reviews.",
  },
];

const HowItWorks = () => {
  return (
    <section id="how-it-works" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            How <span className="text-primary">ShareHub</span> Works
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Getting started is simple. Whether you're renting out or looking to rent, 
            our platform makes the process smooth and secure.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div
                key={index}
                className="relative bg-card p-8 rounded-2xl shadow-sm hover:shadow-md transition-all duration-300 border border-border"
              >
                {/* Step Number */}
                <div className="absolute -top-4 -left-4 w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-xl shadow-lg">
                  {index + 1}
                </div>
                
                {/* Icon */}
                <div className="mb-6 mt-2">
                  <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center">
                    <Icon className="h-7 w-7 text-primary" />
                  </div>
                </div>

                {/* Content */}
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-foreground/70 leading-relaxed">
                  {step.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
