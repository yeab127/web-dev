import { Home, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <Link to="/" className="flex items-center gap-2 font-bold text-xl text-primary mb-4">
              <Home className="h-6 w-6" />
              <span>ShareHub</span>
            </Link>
            <p className="text-sm text-foreground/70 mb-4">
              Unlock the value of your assets through trusted community sharing.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-9 h-9 bg-primary/10 rounded-lg flex items-center justify-center hover:bg-primary/20 transition-colors">
                <Facebook className="h-4 w-4 text-primary" />
              </a>
              <a href="#" className="w-9 h-9 bg-primary/10 rounded-lg flex items-center justify-center hover:bg-primary/20 transition-colors">
                <Twitter className="h-4 w-4 text-primary" />
              </a>
              <a href="#" className="w-9 h-9 bg-primary/10 rounded-lg flex items-center justify-center hover:bg-primary/20 transition-colors">
                <Instagram className="h-4 w-4 text-primary" />
              </a>
              <a href="#" className="w-9 h-9 bg-primary/10 rounded-lg flex items-center justify-center hover:bg-primary/20 transition-colors">
                <Linkedin className="h-4 w-4 text-primary" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/#how-it-works" className="text-sm text-foreground/70 hover:text-primary transition-colors">How It Works</a></li>
              <li><Link to="/browse" className="text-sm text-foreground/70 hover:text-primary transition-colors">Browse Listings</Link></li>
              <li><Link to="/list-asset" className="text-sm text-foreground/70 hover:text-primary transition-colors">List Your Asset</Link></li>
              <li><a href="/#trust-safety" className="text-sm text-foreground/70 hover:text-primary transition-colors">Trust & Safety</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold mb-4">Support</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Help Center</a></li>
              <li><a href="#contact" className="text-sm text-foreground/70 hover:text-primary transition-colors">Contact Us</a></li>
              <li><a href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Safety Guidelines</a></li>
              <li><a href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">FAQ</a></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Terms of Service</a></li>
              <li><a href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Cookie Policy</a></li>
              <li><a href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Refund Policy</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-border text-center text-sm text-foreground/60">
          <p>© 2025 ShareHub. All rights reserved. Built with ❤️ for the sharing economy.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
