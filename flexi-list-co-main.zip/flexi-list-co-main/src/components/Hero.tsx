import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, Search } from "lucide-react";
import heroImage from "@/assets/hero-image.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center pt-16">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt="Modern sharing economy platform"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/85 to-background/60" />
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-2xl">
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
            Unlock the Value of{" "}
            <span className="text-primary">Your Assets</span>
          </h1>
          <p className="text-xl md:text-2xl text-foreground/80 mb-8 leading-relaxed">
            Connect with a trusted community to rent out your property or equipment, 
            or find exactly what you need — without the commitment of ownership.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Button 
              size="lg" 
              className="text-lg bg-gradient-to-r from-primary to-primary/90 hover:opacity-90 shadow-lg"
              asChild
            >
              <Link to="/browse">
                <Search className="mr-2 h-5 w-5" />
                Browse Rentals
              </Link>
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="text-lg border-2"
              asChild
            >
              <Link to="/list-asset">
                List Your Asset
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="flex flex-wrap gap-8 text-sm text-foreground/70">
            <div>
              <div className="text-3xl font-bold text-primary mb-1">10K+</div>
              <div>Active Users</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-1">5K+</div>
              <div>Listed Assets</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-1">4.9/5</div>
              <div>Average Rating</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
