import { useState } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, DollarSign, MapPin } from "lucide-react";
import { toast } from "sonner";

const ListAsset = () => {
  const [formData, setFormData] = useState({
    title: "",
    category: "",
    description: "",
    price: "",
    location: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Asset listed successfully! Our team will review it shortly.");
    setFormData({
      title: "",
      category: "",
      description: "",
      price: "",
      location: "",
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            {/* Header */}
            <div className="mb-12">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                List Your <span className="text-primary">Asset</span>
              </h1>
              <p className="text-lg text-foreground/70">
                Start earning by sharing your property or equipment with our trusted community
              </p>
            </div>

            {/* Benefits */}
            <div className="grid sm:grid-cols-3 gap-4 mb-12">
              <div className="bg-primary/5 p-6 rounded-xl border border-primary/20">
                <div className="text-3xl font-bold text-primary mb-2">5%</div>
                <div className="text-sm text-foreground/70">Low platform fee</div>
              </div>
              <div className="bg-secondary/5 p-6 rounded-xl border border-secondary/20">
                <div className="text-3xl font-bold text-secondary mb-2">24/7</div>
                <div className="text-sm text-foreground/70">Support available</div>
              </div>
              <div className="bg-accent/5 p-6 rounded-xl border border-accent/20">
                <div className="text-3xl font-bold text-accent mb-2">10K+</div>
                <div className="text-sm text-foreground/70">Potential renters</div>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="bg-card p-8 rounded-2xl border border-border space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Asset Title *</label>
                <Input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                  placeholder="e.g., Modern Downtown Apartment"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Category *</label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="properties">Properties</SelectItem>
                    <SelectItem value="tools">Tools & Equipment</SelectItem>
                    <SelectItem value="photography">Photography Equipment</SelectItem>
                    <SelectItem value="vehicles">Vehicles</SelectItem>
                    <SelectItem value="audio">Audio & Music</SelectItem>
                    <SelectItem value="sports">Sports & Outdoor</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Description *</label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                  placeholder="Describe your asset, its condition, and any special features..."
                  rows={5}
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Daily Rate ($) *</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-foreground/40" />
                    <Input
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      required
                      placeholder="50"
                      className="pl-9"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Location *</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-foreground/40" />
                    <Input
                      type="text"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      required
                      placeholder="City, State"
                      className="pl-9"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Upload Photos</label>
                <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary/50 transition-colors cursor-pointer">
                  <Upload className="h-12 w-12 text-foreground/40 mx-auto mb-3" />
                  <p className="text-sm text-foreground/70 mb-1">
                    Click to upload or drag and drop
                  </p>
                  <p className="text-xs text-foreground/50">
                    PNG, JPG up to 10MB
                  </p>
                </div>
              </div>

              <div className="pt-4">
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-primary to-primary/90 text-lg py-6"
                >
                  Submit Listing
                </Button>
                <p className="text-xs text-center text-foreground/60 mt-4">
                  By submitting, you agree to our Terms of Service and Privacy Policy
                </p>
              </div>
            </form>

            {/* Additional Info */}
            <div className="mt-8 bg-muted/30 p-6 rounded-xl">
              <h3 className="font-semibold mb-3">What happens next?</h3>
              <ol className="space-y-2 text-sm text-foreground/70">
                <li>1. Our team reviews your listing (usually within 24 hours)</li>
                <li>2. Once approved, your asset goes live on the platform</li>
                <li>3. You'll receive notifications when renters show interest</li>
                <li>4. Connect with renters and start earning!</li>
              </ol>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default ListAsset;
