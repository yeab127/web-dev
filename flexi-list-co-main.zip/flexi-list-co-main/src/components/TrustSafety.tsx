import { Shield, Lock, CheckCircle2, Users } from "lucide-react";

const features = [
  {
    icon: Shield,
    title: "Verified Users",
    description: "All users go through identity verification to ensure a safe community.",
  },
  {
    icon: Lock,
    title: "Secure Payments",
    description: "End-to-end encrypted transactions with buyer and seller protection.",
  },
  {
    icon: CheckCircle2,
    title: "Transparent Reviews",
    description: "Honest ratings and reviews from real users help you make informed decisions.",
  },
  {
    icon: Users,
    title: "24/7 Support",
    description: "Our dedicated team is here to help resolve any issues quickly.",
  },
];

const TrustSafety = () => {
  return (
    <section id="trust-safety" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Trust & <span className="text-primary">Safety</span> First
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            We've built a platform where safety and transparency are at the core. 
            Your peace of mind is our priority.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="text-center"
              >
                <div className="mb-6 flex justify-center">
                  <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center">
                    <Icon className="h-10 w-10 text-primary" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-foreground/70 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Additional Info */}
        <div className="mt-16 bg-primary/5 rounded-2xl p-8 md:p-12 text-center border border-primary/20">
          <h3 className="text-2xl font-semibold mb-4">
            Questions about safety?
          </h3>
          <p className="text-foreground/70 mb-6 max-w-2xl mx-auto">
            Check out our comprehensive Safety Guidelines or reach out to our support team anytime.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#contact" className="text-primary font-medium hover:underline">
              Contact Support
            </a>
            <span className="hidden sm:inline text-foreground/30">•</span>
            <a href="#" className="text-primary font-medium hover:underline">
              Read Safety Guidelines
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrustSafety;
