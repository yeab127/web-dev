import { Target, Heart, Zap } from "lucide-react";

const values = [
  {
    icon: Target,
    title: "Our Mission",
    description: "To make asset sharing accessible, affordable, and trustworthy for everyone.",
  },
  {
    icon: Heart,
    title: "Community First",
    description: "Building a platform where people help people thrive through shared resources.",
  },
  {
    icon: Zap,
    title: "Innovation",
    description: "Leveraging technology to create seamless, efficient rental experiences.",
  },
];

const AboutUs = () => {
  return (
    <section id="about" className="py-24">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              About <span className="text-primary">ShareHub</span>
            </h2>
            <p className="text-lg text-foreground/70 leading-relaxed mb-6">
              We believe that everyone should have access to the resources they need, 
              when they need them — without the burden of ownership.
            </p>
            <p className="text-lg text-foreground/70 leading-relaxed mb-8">
              ShareHub was born from a simple idea: unlock the value of underutilized assets 
              by connecting property owners and equipment owners with people seeking flexible, 
              short-term rental solutions. Together, we're building a more sustainable, 
              efficient, and community-driven future.
            </p>
            
            <div className="space-y-4">
              {values.map((value, index) => {
                const Icon = value.icon;
                return (
                  <div key={index} className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg mb-1">{value.title}</h3>
                      <p className="text-foreground/70">{value.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Stats */}
          <div className="grid sm:grid-cols-2 gap-6">
            <div className="bg-card p-8 rounded-2xl border border-border">
              <div className="text-5xl font-bold text-primary mb-2">10K+</div>
              <div className="text-foreground/70">Active Community Members</div>
            </div>
            <div className="bg-card p-8 rounded-2xl border border-border">
              <div className="text-5xl font-bold text-secondary mb-2">5K+</div>
              <div className="text-foreground/70">Assets Listed</div>
            </div>
            <div className="bg-card p-8 rounded-2xl border border-border">
              <div className="text-5xl font-bold text-accent mb-2">15K+</div>
              <div className="text-foreground/70">Successful Rentals</div>
            </div>
            <div className="bg-card p-8 rounded-2xl border border-border">
              <div className="text-5xl font-bold text-primary mb-2">4.9</div>
              <div className="text-foreground/70">Average Rating</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
